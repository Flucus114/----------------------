import math, random
import numpy as np
from PIL import Image

OUT_J = '/home/claude/classselector/src/main/java/com/classselector/CosmicBossModel.java'
OUT_T = '/home/claude/classselector/src/main/resources/assets/classselector/textures/entity/'
TEX_W = TEX_H = 256

# name, parent, pivot, origin, size, style, rot
P = []
def part(name, parent, pivot, org, size, style, rot=(0,0,0), g=(0.0,1.0)):
    P.append(dict(name=name, parent=parent, pivot=pivot, org=org, size=size, style=style, rot=rot, g=g))

part('torso', None, (0,-38,0), (-10,-9,-6), (20,18,12), 'torso')
part('head', 'torso', (0,-16,0), (-6,-6,-6), (12,12,12), 'head')
# chifres curvos: 6 segmentos que afinam e dobram para fora, com a ponta curvando de volta
HW = [6,6,4,4,2,2]
HRZ = [0.35,0.2,0.2,0.05,-0.2,-0.2]
for side, sx, sg in (('P',5,1),('N',-5,-1)):
    prev='head'
    for k,w in enumerate(HW):
        piv = (sx,-5,0) if k==0 else (0,-3,0)
        nm='horn%s_%d'%(side,k)
        part(nm, prev, piv, (-(w//2),-3,-(w//2)), (w,3,w), 'horn', (0,0,sg*HRZ[k]), g=(k/6.0,(k+1)/6.0))
        prev=nm
part('crown', 'head', (0,-6,0), (-2,-12,-2), (4,12,4), 'crystal')
for side, sx in (('P',15),('N',-15)):
    part('shoulder'+side, 'torso', (sx,-5,0), (-5,-5,-5), (10,10,10), 'armor')
    part('arm'+side, 'shoulder'+side, (0,3,0), (-4,0,-4), (8,14,8), 'armor')
    part('fore'+side, 'arm'+side, (0,14,0), (-4,0,-4), (8,13,8), 'armor2')
    part('hand'+side, 'fore'+side, (0,13,0), (-4,0,-2), (8,4,4), 'crystal', g=(0.0,0.35))
    for k in range(5):
        part('f%s%d'%(side,k), 'hand'+side, ((k-2)*1.5,4,0), (-1,0,-1), (2,9,2), 'crystal', (-0.15,0,-(k-2)*0.28), g=(0.35,1.0))
# espinhos nas costas: 10 espinhos curvos de 4 segmentos, em leque
SW = [4,4,2,2]; SH = [5,5,4,4]
SPK = [(3,-8,0.12),(7,-8,0.30),(11,-7,0.50),(14,-6,0.72),(16,-4,0.95)]
si = 0
for sg in (1,-1):
    for (x,y,zr) in SPK:
        prev='torso'
        for k in range(4):
            nm='sp%d_%d'%(si,k)
            if k==0:
                piv=(sg*x,y,5); rot=(-0.5,0,sg*zr)
            else:
                piv=(0,-SH[k-1],0); rot=(-0.12,0,sg*0.14)
            w=SW[k]; h=SH[k]
            part(nm, prev, piv, (-(w//2),-h,-(w//2)), (w,h,w), 'spike', rot, g=(k/4.0,(k+1)/4.0))
            prev=nm
        si += 1
part('pelvis', 'torso', (0,11,0), (-6,-3,-5), (12,6,10), 'armor')
part('orb', 'pelvis', (0,1,-7), (-5,-5,-5), (10,10,10), 'galaxy')
for i,(x,y,z) in enumerate([(-6,3,6),(0,4,7),(6,3,6)]):
    part('bo%d'%i, 'pelvis', (x,y,z), (-2,-2,-2), (4,4,4), 'galaxy')
# rabo longo: 8 segmentos
TW = [(10,8),(8,6),(8,6),(6,6),(6,4),(4,4),(4,2),(2,2)]
prev='pelvis'
for k,(w,d) in enumerate(TW):
    h = 7 if k==len(TW)-1 else 6
    nm='tail%d'%k
    part(nm, prev, (0,3 if k==0 else 6,0), (-(w//2),0,-(d//2)), (w,h,d), 'nebula', g=(k/8.0,(k+1)/8.0))
    prev=nm

# ---- packing (shelf) ----
def net(sz):
    w,h,d = sz
    return 2*(w+d), h+d
order = sorted(P, key=lambda p: -net(p['size'])[1])
x=y=shelf=0
for p in order:
    nw,nh = net(p['size'])
    if x+nw > TEX_W:
        x=0; y+=shelf; shelf=0
    p['uv']=(x,y); x+=nw; shelf=max(shelf,nh)
assert y+shelf <= TEX_H, y+shelf

# ---- painting ----
rng = np.random.default_rng(7)
base = np.zeros((TEX_H,TEX_W,4),dtype=np.uint8)
glow = np.zeros((TEX_H,TEX_W,4),dtype=np.uint8); glow[...,3]=255
def clamp(c): return tuple(int(max(0,min(255,v))) for v in c)
def mix(a,b,t): return tuple(a[i]+(b[i]-a[i])*t for i in range(3))
def hsh(a,b,s=0): return ((a*73856093) ^ (b*19349663) ^ (s*83492791)) & 0xffff

PURPLE=(140,90,255); LAV=(190,150,255); CYAN=(90,200,255); WHITE=(240,235,255)

def ramp(t, stops):
    t=max(0.0,min(1.0,t))
    for (t0,c0),(t1,c1) in zip(stops, stops[1:]):
        if t<=t1:
            f=(t-t0)/(t1-t0) if t1>t0 else 0
            return mix(c0,c1,f)
    return stops[-1][1]

CR=[(0,(80,50,210)),(0.4,(70,110,255)),(0.75,(130,230,255)),(1,(235,245,255))]
HR=[(0,(18,14,38)),(0.45,(60,45,130)),(0.8,(150,120,255)),(1,(235,230,255))]
SR=[(0,(14,10,30)),(0.5,(40,25,90)),(1,(160,95,255))]
TR=[(0,(70,30,150)),(0.3,(145,50,210)),(0.55,(60,85,235)),(0.8,(50,175,240)),(1,(140,238,255))]
OR=[(0,(240,250,255)),(0.25,(110,220,255)),(0.55,(80,100,240)),(1,(160,60,215))]

def armor(fw,fh,i,j,glowvein=0.05):
    n = rng.random()
    nb = (hsh(i//3,j//3,9)%100)/100.0
    b = mix(mix((14,12,32),(34,26,70), n), (50,32,110), nb*0.35)
    g = None
    if i in (0,fw-1) or j in (0,fh-1): b = mix(b,(64,50,118),0.6)
    if i%6==3 and j%6==3 and fw>5 and fh>5: b=(78,62,120)
    if rng.random()<glowvein and fw>3 and fh>3:
        b=(90,56,190); g=(120,80,230)
    elif rng.random()<0.03:
        b=(150,170,255); g=(110,130,220)   # estrelinhas
    return b,g

def paint(p, face, i, j, fw, fh):
    st=p['style']
    g0,g1=p['g']
    if face=='top': tt=g0
    elif face=='bottom': tt=g1
    else: tt=g0+(g1-g0)*(j/max(1,fh-1))
    if st=='torso':
        if face=='front':
            cx,cy=(fw-1)/2,(fh-1)/2
            if 6<=i<=13 and 2<=j<=15:
                edge = i in (6,13) or j in (2,15)
                if edge: return PURPLE,PURPLE
                d=math.hypot(i-cx,j-cy)
                if abs(d-3.2)<0.7: return LAV,LAV
                if d<1.3: return WHITE,WHITE
                return (14,10,26),None
            for x0 in (1,15):
                if x0<=i<=x0+3 and 4<=j<=10:
                    if i in (x0,x0+3) or j in (4,10): return (110,70,230),(140,90,255)
                    if hsh(i,j,1)%3==0: return LAV,LAV
                    return (14,10,26),None
        if face=='back':
            cx,cy=(fw-1)/2,(fh-1)/2
            r=math.hypot(i-cx,j-cy); a=math.atan2(j-cy,i-cx)
            if r<7.5:
                v=math.sin(a*2+r*0.9)
                c = mix((90,50,200),(120,220,255),(v+1)/2) if r>1.5 else WHITE
                if abs(r-7)<0.8: c=PURPLE
                return clamp(c),clamp(c)
        return armor(fw,fh,i,j,0.06)
    if st=='head':
        if face=='front':
            ex,ey=5.5,3.9
            d=math.hypot(i-ex,(j-ey)*0.92)
            if i==4 and j==2: return WHITE,WHITE                       # brilho no olho
            if abs(i-ex)<1.3 and abs(j-ey)<2.7: return (0,0,0),None     # pupila preta
            if d<2.6: return clamp(mix((120,150,255),(190,150,255),d/2.6)),clamp(mix((120,150,255),(190,150,255),d/2.6))  # iris
            if d<3.6: return LAV,LAV
            if d<4.5: return PURPLE,PURPLE
            if d<5.6: return (5,4,10),None                              # orbita escura
            # boca com dentes
            if 8<=j<=10 and 2<=i<=9:
                if j==9: return (0,0,0),None
                if j==8: return ((170,130,255),(150,115,235)) if i%2==0 else ((0,0,0),None)
                if j==10: return ((170,130,255),(150,115,235)) if i%2==1 else ((0,0,0),None)
            if j==9 and i in (1,10): return (70,45,140),(80,50,160)     # cantos da boca
        return armor(fw,fh,i,j,0.04)
    if st=='armor': return armor(fw,fh,i,j,0.05)
    if st=='armor2':
        b,g=armor(fw,fh,i,j,0.03)
        if face in('front','back') and 2<=i<=fw-3 and j%5==2 and hsh(i,j,2)%2==0: return PURPLE,PURPLE
        return b,g
    if st=='spike':
        c=ramp(tt,SR)
        n=(hsh(i,j,11)%100)/100.0
        c=mix(c,(0,0,0),0.15*n)
        gl=mix((0,0,0),c,max(0.0,(tt-0.35)/0.65))
        if rng.random()<0.06: c=(170,180,255); gl=c
        return clamp(c),clamp(gl)
    if st=='horn':
        c=ramp(tt,HR)
        f=(hsh(i,j,12)%100)/100.0
        c=mix(c,(255,255,255),0.08*f) if tt>0.6 else mix(c,(0,0,0),0.1*f)
        gl=mix((0,0,0),c,max(0.0,(tt-0.4)/0.6)**1.3)
        return clamp(c),clamp(gl)
    if st=='crystal':
        f=(hsh(i//2,j//3,3)%100)/100.0
        c=ramp(tt+(f-0.5)*0.18,CR)
        if hsh(i,j,4)%23==0: c=WHITE
        c=clamp(c); return c,clamp(mix(c,(0,0,0),0.1))
    if st=='galaxy':
        cx,cy=(fw-1)/2,(fh-1)/2
        R=max(cx,cy)+0.5
        r=math.hypot(i-cx,j-cy); a=math.atan2(j-cy,i-cx)
        t=r/R+0.18*math.sin(a*2+r*0.9)
        c=ramp(t,OR)
        if rng.random()<0.06: c=WHITE
        c=clamp(c); return c,c
    if st=='nebula':
        v=math.sin(i*0.9+j*0.55+hsh(i//2,j//2,6)%5)
        c=ramp(tt+0.04*v,TR)
        if v>0.55: c=mix(c,(215,95,235),0.35)       # veios magenta
        if v<-0.7: c=mix(c,(20,15,70),0.35)
        if rng.random()<0.08: c=(215,225,255)
        c=clamp(c)
        return c,clamp(mix(c,(0,0,0),0.12))
    return (255,0,255),None

for p in P:
    u,v=p['uv']; w,h,d=p['size']
    faces={'top':(u+d,v,w,d),'bottom':(u+d+w,v,w,d),'west':(u,v+d,d,h),
           'front':(u+d,v+d,w,h),'east':(u+d+w,v+d,d,h),'back':(u+2*d+w,v+d,w,h)}
    for fn,(fx,fy,fw,fh) in faces.items():
        for j in range(fh):
            for i in range(fw):
                b,g=paint(p,fn,i,j,fw,fh)
                base[fy+j,fx+i]=(*clamp(b),255)
                if g is not None: glow[fy+j,fx+i]=(*clamp(g),255)

import os
os.makedirs(OUT_T,exist_ok=True)
Image.fromarray(base,'RGBA').save(OUT_T+'cosmic_sovereign.png')
Image.fromarray(glow,'RGBA').save(OUT_T+'cosmic_sovereign_glow.png')

# ---- java ----
def f(v):
    s=('%.3f'%v).rstrip('0').rstrip('.')
    return (s if s else '0')+'F'
lines=[]
for p in P:
    var=p['name']; par='root' if p['parent'] is None else p['parent']
    u,v=p['uv']; ox,oy,oz=p['org']; w,h,d=p['size']; px,py,pz=p['pivot']; rx,ry,rz=p['rot']
    lines.append('        PartDefinition %s = %s.addOrReplaceChild("%s", CubeListBuilder.create().texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s), PartPose.offsetAndRotation(%s, %s, %s, %s, %s, %s));'
      %(var,par,var,u,v,f(ox),f(oy),f(oz),f(w),f(h),f(d),f(px),f(py),f(pz),f(rx),f(ry),f(rz)))
build='\n'.join(lines)

java = '''package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Modelo do Soberano Cósmico. GERADO por gen_boss.py (geometria + UVs da textura).
 * As animações ficam em setupAnim.
 */
public class CosmicBossModel extends EntityModel<CosmicBoss> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ClassSelectorMod.MODID, "cosmic_sovereign"), "main");
    private static final float RAD = (float) Math.PI / 180F;
    private static final float TORSO_Y = -38.0F;
    private static final int SPIKES = 10, SPIKE_SEGS = 4, HORN_SEGS = 6, TAIL_SEGS = 8;

    private final ModelPart root, torso, head, orb;
    private final ModelPart[] arm = new ModelPart[2], fore = new ModelPart[2], hand = new ModelPart[2];
    private final ModelPart[][] fingers = new ModelPart[2][5];
    private final ModelPart[][] spike = new ModelPart[SPIKES][SPIKE_SEGS];
    private final float[][] spikeBaseX = new float[SPIKES][SPIKE_SEGS], spikeBaseZ = new float[SPIKES][SPIKE_SEGS];
    private final ModelPart[] backOrbs = new ModelPart[3], tail = new ModelPart[TAIL_SEGS];

    public CosmicBossModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.head = torso.getChild("head");
        ModelPart pelvis = torso.getChild("pelvis");
        this.orb = pelvis.getChild("orb");
        String[] sides = {"P", "N"};
        for (int s = 0; s < 2; s++) {
            ModelPart sh = torso.getChild("shoulder" + sides[s]);
            arm[s] = sh.getChild("arm" + sides[s]);
            fore[s] = arm[s].getChild("fore" + sides[s]);
            hand[s] = fore[s].getChild("hand" + sides[s]);
            for (int k = 0; k < 5; k++) fingers[s][k] = hand[s].getChild("f" + sides[s] + k);
        }
        for (int i = 0; i < SPIKES; i++) {
            ModelPart prev = torso;
            for (int k = 0; k < SPIKE_SEGS; k++) {
                spike[i][k] = prev.getChild("sp" + i + "_" + k);
                spikeBaseX[i][k] = spike[i][k].xRot;
                spikeBaseZ[i][k] = spike[i][k].zRot;
                prev = spike[i][k];
            }
        }
        for (int i = 0; i < 3; i++) backOrbs[i] = pelvis.getChild("bo" + i);
        ModelPart prev = pelvis;
        for (int i = 0; i < TAIL_SEGS; i++) { tail[i] = prev.getChild("tail" + i); prev = tail[i]; }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
%s
        return LayerDefinition.create(mesh, %d, %d);
    }

    @Override
    public void setupAnim(CosmicBoss e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        float t = age;
        float[] w = e.getPoseWeights(); // 0 parado, 1 orbes, 2 pulso, 3 raio

        torso.y = TORSO_Y + Mth.sin(t * 0.09F) * 1.6F;
        torso.xRot = 0.05F + w[2] * -0.2F + w[3] * 0.1F;
        head.yRot = yaw * RAD * 0.7F;
        head.xRot = pitch * RAD * 0.7F;

        float armX = w[1] * -1.3F + w[3] * -1.5F;
        float armZ = w[0] * (0.9F + Mth.sin(t * 0.08F) * 0.08F) + w[1] * 0.35F + w[2] * 2.7F + w[3] * 0.12F;
        float foreZ = w[0] * 1.4F + w[1] * 0.2F + w[2] * 0.2F;
        float foreX = (w[0] + w[1]) * -0.3F;
        for (int s = 0; s < 2; s++) {
            float sg = s == 0 ? -1.0F : 1.0F; // lado +x gira para fora com z negativo
            arm[s].xRot = armX;
            arm[s].zRot = sg * armZ;
            fore[s].xRot = foreX;
            fore[s].zRot = sg * foreZ;
            hand[s].zRot = sg * 0.2F;
            for (int k = 0; k < 5; k++) {
                float open = 1.0F + 0.5F * (w[1] + w[3]);
                fingers[s][k].zRot = -(k - 2) * 0.28F * open;
                fingers[s][k].xRot = -0.15F + Mth.sin(t * 0.12F + k) * 0.05F;
            }
        }

        for (int i = 0; i < TAIL_SEGS; i++) {
            tail[i].xRot = 0.06F + Mth.sin(t * 0.09F - i * 0.6F) * 0.10F;
            tail[i].yRot = Mth.sin(t * 0.07F - i * 0.7F) * 0.20F;
        }
        orb.yRot = t * 0.04F;
        orb.xRot = t * 0.025F;
        for (int i = 0; i < 3; i++) backOrbs[i].yRot = -t * 0.06F + i;
        for (int i = 0; i < SPIKES; i++) {
            for (int k = 0; k < SPIKE_SEGS; k++) {
                float ph = t * 0.06F + i * 0.7F + k * 0.6F;
                spike[i][k].zRot = spikeBaseZ[i][k] + Mth.sin(ph) * 0.05F;
                spike[i][k].xRot = spikeBaseX[i][k] + Mth.cos(ph) * 0.03F;
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buf, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buf, light, overlay, r, g, b, a);
    }
}
''' % (build, TEX_W, TEX_H)
open(OUT_J,'w',encoding='utf-8').write(java)
print('parts',len(P),'used height',y+shelf)
