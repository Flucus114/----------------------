package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Modelo do Soberano Cósmico. GERADO por gen_boss.py (geometria + UVs da textura).
 * As animações ficam em setupAnim.
 */
public class CosmicBossModel extends EntityModel<CosmicBoss> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ClassSelectorMod.MODID, "cosmic_sovereign"), "main");
    private static final float RAD = (float) Math.PI / 180F;
    private static final float TORSO_Y = -38.0F;
    private static final int SPIKES = 10, SPIKE_SEGS = 4, HORN_SEGS = 6, TAIL_SEGS = 8;

    private final ModelPart root, torso, head, orb;
    private final ModelPart[] arm = new ModelPart[2], fore = new ModelPart[2], hand = new ModelPart[2];
    private final ModelPart[][] fingers = new ModelPart[2][5];
    private final ModelPart[][] spike = new ModelPart[SPIKES][SPIKE_SEGS];
    private final float[][] spikeBaseX = new float[SPIKES][SPIKE_SEGS], spikeBaseZ = new float[SPIKES][SPIKE_SEGS];
    private final ModelPart[] backOrbs = new ModelPart[3], tail = new ModelPart[TAIL_SEGS];

    public CosmicBossModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.head = torso.getChild("head");
        ModelPart pelvis = torso.getChild("pelvis");
        this.orb = pelvis.getChild("orb");
        String[] sides = {"P", "N"};
        for (int s = 0; s < 2; s++) {
            ModelPart sh = torso.getChild("shoulder" + sides[s]);
            arm[s] = sh.getChild("arm" + sides[s]);
            fore[s] = arm[s].getChild("fore" + sides[s]);
            hand[s] = fore[s].getChild("hand" + sides[s]);
            for (int k = 0; k < 5; k++) fingers[s][k] = hand[s].getChild("f" + sides[s] + k);
        }
        for (int i = 0; i < SPIKES; i++) {
            ModelPart prev = torso;
            for (int k = 0; k < SPIKE_SEGS; k++) {
                spike[i][k] = prev.getChild("sp" + i + "_" + k);
                spikeBaseX[i][k] = spike[i][k].xRot;
                spikeBaseZ[i][k] = spike[i][k].zRot;
                prev = spike[i][k];
            }
        }
        for (int i = 0; i < 3; i++) backOrbs[i] = pelvis.getChild("bo" + i);
        ModelPart prev = pelvis;
        for (int i = 0; i < TAIL_SEGS; i++) { tail[i] = prev.getChild("tail" + i); prev = tail[i]; }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition torso = root.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 0).addBox(-10F, -9F, -6F, 20F, 18F, 12F), PartPose.offsetAndRotation(0F, -38F, 0F, 0F, 0F, 0F));
        PartDefinition head = torso.addOrReplaceChild("head", CubeListBuilder.create().texOffs(64, 0).addBox(-6F, -6F, -6F, 12F, 12F, 12F), PartPose.offsetAndRotation(0F, -16F, 0F, 0F, 0F, 0F));
        PartDefinition hornP_0 = head.addOrReplaceChild("hornP_0", CubeListBuilder.create().texOffs(168, 50).addBox(-3F, -3F, -3F, 6F, 3F, 6F), PartPose.offsetAndRotation(5F, -5F, 0F, 0F, 0F, 0.35F));
        PartDefinition hornP_1 = hornP_0.addOrReplaceChild("hornP_1", CubeListBuilder.create().texOffs(192, 50).addBox(-3F, -3F, -3F, 6F, 3F, 6F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition hornP_2 = hornP_1.addOrReplaceChild("hornP_2", CubeListBuilder.create().texOffs(212, 71).addBox(-2F, -3F, -2F, 4F, 3F, 4F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition hornP_3 = hornP_2.addOrReplaceChild("hornP_3", CubeListBuilder.create().texOffs(228, 71).addBox(-2F, -3F, -2F, 4F, 3F, 4F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.05F));
        PartDefinition hornP_4 = hornP_3.addOrReplaceChild("hornP_4", CubeListBuilder.create().texOffs(192, 80).addBox(-1F, -3F, -1F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition hornP_5 = hornP_4.addOrReplaceChild("hornP_5", CubeListBuilder.create().texOffs(200, 80).addBox(-1F, -3F, -1F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition hornN_0 = head.addOrReplaceChild("hornN_0", CubeListBuilder.create().texOffs(216, 50).addBox(-3F, -3F, -3F, 6F, 3F, 6F), PartPose.offsetAndRotation(-5F, -5F, 0F, 0F, 0F, -0.35F));
        PartDefinition hornN_1 = hornN_0.addOrReplaceChild("hornN_1", CubeListBuilder.create().texOffs(0, 62).addBox(-3F, -3F, -3F, 6F, 3F, 6F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition hornN_2 = hornN_1.addOrReplaceChild("hornN_2", CubeListBuilder.create().texOffs(0, 80).addBox(-2F, -3F, -2F, 4F, 3F, 4F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.2F));
        PartDefinition hornN_3 = hornN_2.addOrReplaceChild("hornN_3", CubeListBuilder.create().texOffs(16, 80).addBox(-2F, -3F, -2F, 4F, 3F, 4F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, -0.05F));
        PartDefinition hornN_4 = hornN_3.addOrReplaceChild("hornN_4", CubeListBuilder.create().texOffs(208, 80).addBox(-1F, -3F, -1F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition hornN_5 = hornN_4.addOrReplaceChild("hornN_5", CubeListBuilder.create().texOffs(216, 80).addBox(-1F, -3F, -1F, 2F, 3F, 2F), PartPose.offsetAndRotation(0F, -3F, 0F, 0F, 0F, 0.2F));
        PartDefinition crown = head.addOrReplaceChild("crown", CubeListBuilder.create().texOffs(120, 30).addBox(-2F, -12F, -2F, 4F, 12F, 4F), PartPose.offsetAndRotation(0F, -6F, 0F, 0F, 0F, 0F));
        PartDefinition shoulderP = torso.addOrReplaceChild("shoulderP", CubeListBuilder.create().texOffs(0, 30).addBox(-5F, -5F, -5F, 10F, 10F, 10F), PartPose.offsetAndRotation(15F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition armP = shoulderP.addOrReplaceChild("armP", CubeListBuilder.create().texOffs(112, 0).addBox(-4F, 0F, -4F, 8F, 14F, 8F), PartPose.offsetAndRotation(0F, 3F, 0F, 0F, 0F, 0F));
        PartDefinition foreP = armP.addOrReplaceChild("foreP", CubeListBuilder.create().texOffs(176, 0).addBox(-4F, 0F, -4F, 8F, 13F, 8F), PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, 0F));
        PartDefinition handP = foreP.addOrReplaceChild("handP", CubeListBuilder.create().texOffs(104, 71).addBox(-4F, 0F, -2F, 8F, 4F, 4F), PartPose.offsetAndRotation(0F, 13F, 0F, 0F, 0F, 0F));
        PartDefinition fP0 = handP.addOrReplaceChild("fP0", CubeListBuilder.create().texOffs(52, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(-3F, 4F, 0F, -0.15F, 0F, 0.56F));
        PartDefinition fP1 = handP.addOrReplaceChild("fP1", CubeListBuilder.create().texOffs(60, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(-1.5F, 4F, 0F, -0.15F, 0F, 0.28F));
        PartDefinition fP2 = handP.addOrReplaceChild("fP2", CubeListBuilder.create().texOffs(68, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.15F, 0F, 0F));
        PartDefinition fP3 = handP.addOrReplaceChild("fP3", CubeListBuilder.create().texOffs(76, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(1.5F, 4F, 0F, -0.15F, 0F, -0.28F));
        PartDefinition fP4 = handP.addOrReplaceChild("fP4", CubeListBuilder.create().texOffs(84, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(3F, 4F, 0F, -0.15F, 0F, -0.56F));
        PartDefinition shoulderN = torso.addOrReplaceChild("shoulderN", CubeListBuilder.create().texOffs(40, 30).addBox(-5F, -5F, -5F, 10F, 10F, 10F), PartPose.offsetAndRotation(-15F, -5F, 0F, 0F, 0F, 0F));
        PartDefinition armN = shoulderN.addOrReplaceChild("armN", CubeListBuilder.create().texOffs(144, 0).addBox(-4F, 0F, -4F, 8F, 14F, 8F), PartPose.offsetAndRotation(0F, 3F, 0F, 0F, 0F, 0F));
        PartDefinition foreN = armN.addOrReplaceChild("foreN", CubeListBuilder.create().texOffs(208, 0).addBox(-4F, 0F, -4F, 8F, 13F, 8F), PartPose.offsetAndRotation(0F, 14F, 0F, 0F, 0F, 0F));
        PartDefinition handN = foreN.addOrReplaceChild("handN", CubeListBuilder.create().texOffs(128, 71).addBox(-4F, 0F, -2F, 8F, 4F, 4F), PartPose.offsetAndRotation(0F, 13F, 0F, 0F, 0F, 0F));
        PartDefinition fN0 = handN.addOrReplaceChild("fN0", CubeListBuilder.create().texOffs(92, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(-3F, 4F, 0F, -0.15F, 0F, 0.56F));
        PartDefinition fN1 = handN.addOrReplaceChild("fN1", CubeListBuilder.create().texOffs(100, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(-1.5F, 4F, 0F, -0.15F, 0F, 0.28F));
        PartDefinition fN2 = handN.addOrReplaceChild("fN2", CubeListBuilder.create().texOffs(108, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(0F, 4F, 0F, -0.15F, 0F, 0F));
        PartDefinition fN3 = handN.addOrReplaceChild("fN3", CubeListBuilder.create().texOffs(116, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(1.5F, 4F, 0F, -0.15F, 0F, -0.28F));
        PartDefinition fN4 = handN.addOrReplaceChild("fN4", CubeListBuilder.create().texOffs(124, 50).addBox(-1F, 0F, -1F, 2F, 9F, 2F), PartPose.offsetAndRotation(3F, 4F, 0F, -0.15F, 0F, -0.56F));
        PartDefinition sp0_0 = torso.addOrReplaceChild("sp0_0", CubeListBuilder.create().texOffs(24, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(3F, -8F, 5F, -0.5F, 0F, 0.12F));
        PartDefinition sp0_1 = sp0_0.addOrReplaceChild("sp0_1", CubeListBuilder.create().texOffs(40, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp0_2 = sp0_1.addOrReplaceChild("sp0_2", CubeListBuilder.create().texOffs(32, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp0_3 = sp0_2.addOrReplaceChild("sp0_3", CubeListBuilder.create().texOffs(40, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp1_0 = torso.addOrReplaceChild("sp1_0", CubeListBuilder.create().texOffs(56, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(7F, -8F, 5F, -0.5F, 0F, 0.3F));
        PartDefinition sp1_1 = sp1_0.addOrReplaceChild("sp1_1", CubeListBuilder.create().texOffs(72, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp1_2 = sp1_1.addOrReplaceChild("sp1_2", CubeListBuilder.create().texOffs(48, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp1_3 = sp1_2.addOrReplaceChild("sp1_3", CubeListBuilder.create().texOffs(56, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp2_0 = torso.addOrReplaceChild("sp2_0", CubeListBuilder.create().texOffs(88, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(11F, -7F, 5F, -0.5F, 0F, 0.5F));
        PartDefinition sp2_1 = sp2_0.addOrReplaceChild("sp2_1", CubeListBuilder.create().texOffs(104, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp2_2 = sp2_1.addOrReplaceChild("sp2_2", CubeListBuilder.create().texOffs(64, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp2_3 = sp2_2.addOrReplaceChild("sp2_3", CubeListBuilder.create().texOffs(72, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp3_0 = torso.addOrReplaceChild("sp3_0", CubeListBuilder.create().texOffs(120, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(14F, -6F, 5F, -0.5F, 0F, 0.72F));
        PartDefinition sp3_1 = sp3_0.addOrReplaceChild("sp3_1", CubeListBuilder.create().texOffs(136, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp3_2 = sp3_1.addOrReplaceChild("sp3_2", CubeListBuilder.create().texOffs(80, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp3_3 = sp3_2.addOrReplaceChild("sp3_3", CubeListBuilder.create().texOffs(88, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp4_0 = torso.addOrReplaceChild("sp4_0", CubeListBuilder.create().texOffs(152, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(16F, -4F, 5F, -0.5F, 0F, 0.95F));
        PartDefinition sp4_1 = sp4_0.addOrReplaceChild("sp4_1", CubeListBuilder.create().texOffs(168, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp4_2 = sp4_1.addOrReplaceChild("sp4_2", CubeListBuilder.create().texOffs(96, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp4_3 = sp4_2.addOrReplaceChild("sp4_3", CubeListBuilder.create().texOffs(104, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, 0.14F));
        PartDefinition sp5_0 = torso.addOrReplaceChild("sp5_0", CubeListBuilder.create().texOffs(184, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-3F, -8F, 5F, -0.5F, 0F, -0.12F));
        PartDefinition sp5_1 = sp5_0.addOrReplaceChild("sp5_1", CubeListBuilder.create().texOffs(200, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp5_2 = sp5_1.addOrReplaceChild("sp5_2", CubeListBuilder.create().texOffs(112, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp5_3 = sp5_2.addOrReplaceChild("sp5_3", CubeListBuilder.create().texOffs(120, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp6_0 = torso.addOrReplaceChild("sp6_0", CubeListBuilder.create().texOffs(216, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-7F, -8F, 5F, -0.5F, 0F, -0.3F));
        PartDefinition sp6_1 = sp6_0.addOrReplaceChild("sp6_1", CubeListBuilder.create().texOffs(232, 62).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp6_2 = sp6_1.addOrReplaceChild("sp6_2", CubeListBuilder.create().texOffs(128, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp6_3 = sp6_2.addOrReplaceChild("sp6_3", CubeListBuilder.create().texOffs(136, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp7_0 = torso.addOrReplaceChild("sp7_0", CubeListBuilder.create().texOffs(0, 71).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-11F, -7F, 5F, -0.5F, 0F, -0.5F));
        PartDefinition sp7_1 = sp7_0.addOrReplaceChild("sp7_1", CubeListBuilder.create().texOffs(16, 71).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp7_2 = sp7_1.addOrReplaceChild("sp7_2", CubeListBuilder.create().texOffs(144, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp7_3 = sp7_2.addOrReplaceChild("sp7_3", CubeListBuilder.create().texOffs(152, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp8_0 = torso.addOrReplaceChild("sp8_0", CubeListBuilder.create().texOffs(32, 71).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-14F, -6F, 5F, -0.5F, 0F, -0.72F));
        PartDefinition sp8_1 = sp8_0.addOrReplaceChild("sp8_1", CubeListBuilder.create().texOffs(48, 71).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp8_2 = sp8_1.addOrReplaceChild("sp8_2", CubeListBuilder.create().texOffs(160, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp8_3 = sp8_2.addOrReplaceChild("sp8_3", CubeListBuilder.create().texOffs(168, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp9_0 = torso.addOrReplaceChild("sp9_0", CubeListBuilder.create().texOffs(64, 71).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(-16F, -4F, 5F, -0.5F, 0F, -0.95F));
        PartDefinition sp9_1 = sp9_0.addOrReplaceChild("sp9_1", CubeListBuilder.create().texOffs(80, 71).addBox(-2F, -5F, -2F, 4F, 5F, 4F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp9_2 = sp9_1.addOrReplaceChild("sp9_2", CubeListBuilder.create().texOffs(176, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -5F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition sp9_3 = sp9_2.addOrReplaceChild("sp9_3", CubeListBuilder.create().texOffs(184, 80).addBox(-1F, -4F, -1F, 2F, 4F, 2F), PartPose.offsetAndRotation(0F, -4F, 0F, -0.12F, 0F, -0.14F));
        PartDefinition pelvis = torso.addOrReplaceChild("pelvis", CubeListBuilder.create().texOffs(136, 30).addBox(-6F, -3F, -5F, 12F, 6F, 10F), PartPose.offsetAndRotation(0F, 11F, 0F, 0F, 0F, 0F));
        PartDefinition orb = pelvis.addOrReplaceChild("orb", CubeListBuilder.create().texOffs(80, 30).addBox(-5F, -5F, -5F, 10F, 10F, 10F), PartPose.offsetAndRotation(0F, 1F, -7F, 0F, 0F, 0F));
        PartDefinition bo0 = pelvis.addOrReplaceChild("bo0", CubeListBuilder.create().texOffs(152, 71).addBox(-2F, -2F, -2F, 4F, 4F, 4F), PartPose.offsetAndRotation(-6F, 3F, 6F, 0F, 0F, 0F));
        PartDefinition bo1 = pelvis.addOrReplaceChild("bo1", CubeListBuilder.create().texOffs(168, 71).addBox(-2F, -2F, -2F, 4F, 4F, 4F), PartPose.offsetAndRotation(0F, 4F, 7F, 0F, 0F, 0F));
        PartDefinition bo2 = pelvis.addOrReplaceChild("bo2", CubeListBuilder.create().texOffs(184, 71).addBox(-2F, -2F, -2F, 4F, 4F, 4F), PartPose.offsetAndRotation(6F, 3F, 6F, 0F, 0F, 0F));
        PartDefinition tail0 = pelvis.addOrReplaceChild("tail0", CubeListBuilder.create().texOffs(180, 30).addBox(-5F, 0F, -4F, 10F, 6F, 8F), PartPose.offsetAndRotation(0F, 3F, 0F, 0F, 0F, 0F));
        PartDefinition tail1 = tail0.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(216, 30).addBox(-4F, 0F, -3F, 8F, 6F, 6F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail2 = tail1.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(0, 50).addBox(-4F, 0F, -3F, 8F, 6F, 6F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail3 = tail2.addOrReplaceChild("tail3", CubeListBuilder.create().texOffs(28, 50).addBox(-3F, 0F, -3F, 6F, 6F, 6F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail4 = tail3.addOrReplaceChild("tail4", CubeListBuilder.create().texOffs(132, 50).addBox(-3F, 0F, -2F, 6F, 6F, 4F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail5 = tail4.addOrReplaceChild("tail5", CubeListBuilder.create().texOffs(152, 50).addBox(-2F, 0F, -2F, 4F, 6F, 4F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail6 = tail5.addOrReplaceChild("tail6", CubeListBuilder.create().texOffs(200, 71).addBox(-2F, 0F, -1F, 4F, 6F, 2F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        PartDefinition tail7 = tail6.addOrReplaceChild("tail7", CubeListBuilder.create().texOffs(96, 71).addBox(-1F, 0F, -1F, 2F, 7F, 2F), PartPose.offsetAndRotation(0F, 6F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(CosmicBoss e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        float t = age;
        float[] w = e.getPoseWeights(); // 0 parado, 1 orbes, 2 pulso, 3 raio

        torso.y = TORSO_Y + Mth.sin(t * 0.09F) * 1.6F;
        torso.xRot = 0.05F + w[2] * -0.2F + w[3] * 0.1F;
        head.yRot = yaw * RAD * 0.7F;
        head.xRot = pitch * RAD * 0.7F;

        float armX = w[1] * -1.3F + w[3] * -1.5F;
        float armZ = w[0] * (0.9F + Mth.sin(t * 0.08F) * 0.08F) + w[1] * 0.35F + w[2] * 2.7F + w[3] * 0.12F;
        float foreZ = w[0] * 1.4F + w[1] * 0.2F + w[2] * 0.2F;
        float foreX = (w[0] + w[1]) * -0.3F;
        for (int s = 0; s < 2; s++) {
            float sg = s == 0 ? -1.0F : 1.0F; // lado +x gira para fora com z negativo
            arm[s].xRot = armX;
            arm[s].zRot = sg * armZ;
            fore[s].xRot = foreX;
            fore[s].zRot = sg * foreZ;
            hand[s].zRot = sg * 0.2F;
            for (int k = 0; k < 5; k++) {
                float open = 1.0F + 0.5F * (w[1] + w[3]);
                fingers[s][k].zRot = -(k - 2) * 0.28F * open;
                fingers[s][k].xRot = -0.15F + Mth.sin(t * 0.12F + k) * 0.05F;
            }
        }

        for (int i = 0; i < TAIL_SEGS; i++) {
            tail[i].xRot = 0.06F + Mth.sin(t * 0.09F - i * 0.6F) * 0.10F;
            tail[i].yRot = Mth.sin(t * 0.07F - i * 0.7F) * 0.20F;
        }
        orb.yRot = t * 0.04F;
        orb.xRot = t * 0.025F;
        for (int i = 0; i < 3; i++) backOrbs[i].yRot = -t * 0.06F + i;
        for (int i = 0; i < SPIKES; i++) {
            for (int k = 0; k < SPIKE_SEGS; k++) {
                float ph = t * 0.06F + i * 0.7F + k * 0.6F;
                spike[i][k].zRot = spikeBaseZ[i][k] + Mth.sin(ph) * 0.05F;
                spike[i][k].xRot = spikeBaseX[i][k] + Mth.cos(ph) * 0.03F;
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buf, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buf, light, overlay, r, g, b, a);
    }
}
