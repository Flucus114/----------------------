package com.classselector;

import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

/** Partes que brilham no escuro (olho, runas, cristais, vórtice). */
public class CosmicGlowLayer extends EyesLayer<CosmicBoss, CosmicBossModel> {
    private static final RenderType GLOW = RenderType.eyes(
            new ResourceLocation(ClassSelectorMod.MODID, "textures/entity/cosmic_sovereign_glow.png"));

    public CosmicGlowLayer(RenderLayerParent<CosmicBoss, CosmicBossModel> parent) {
        super(parent);
    }

    @Override
    public RenderType renderType() {
        return GLOW;
    }
}
