package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CosmicBossRenderer extends MobRenderer<CosmicBoss, CosmicBossModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ClassSelectorMod.MODID, "textures/entity/cosmic_sovereign.png");

    private static final float SCALE = 1.3F;

    public CosmicBossRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new CosmicBossModel(ctx.bakeLayer(CosmicBossModel.LAYER)), 2.4F);
        this.addLayer(new CosmicGlowLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(CosmicBoss e) {
        return TEXTURE;
    }

    /** Boss grande: escala do modelo (a caixa de colisão é 4,5 x 8 blocos). */
    @Override
    protected void scale(CosmicBoss e, PoseStack pose, float partialTick) {
        pose.scale(SCALE, SCALE, SCALE);
    }

    /** Não tomba de lado ao morrer (ele flutua). */
    @Override
    protected float getFlipDegrees(CosmicBoss e) {
        return 0.0F;
    }
}
